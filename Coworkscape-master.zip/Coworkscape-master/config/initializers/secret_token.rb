# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Coworkscape::Application.config.secret_token = '09b647fb50529f0873e25f7dca25a3be9c24060c4c0c0d31a0c61befabb30a03b404a7f8c22ff4cefd403bdfc7f765aa20c9a1874ac425b9c38ea0a5fb98c825'
