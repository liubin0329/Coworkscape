require 'test_helper'

class TermsHelperTest < ActionView::TestCase
end
