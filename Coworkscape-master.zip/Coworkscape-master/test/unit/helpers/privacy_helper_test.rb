require 'test_helper'

class PrivacyHelperTest < ActionView::TestCase
end
