require 'test_helper'

class SpacesHelperTest < ActionView::TestCase
end
