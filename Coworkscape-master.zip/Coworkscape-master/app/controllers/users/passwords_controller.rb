class Users::PasswordsController < Devise::PasswordsController
end