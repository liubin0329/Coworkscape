class Users::ConfirmationsController < Devise::ConfirmationsController
  
end