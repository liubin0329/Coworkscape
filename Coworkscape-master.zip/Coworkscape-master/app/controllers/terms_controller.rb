class TermsController < ApplicationController
  def index
  end
end
