module PrivacyHelper
end
